
-- DROP tables if already exist (correct order for FK constraints)
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS ProductArchive;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Customers;

-- Create Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(15),
    Address VARCHAR(255)
);

-- Create Products table
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    Name VARCHAR(100),
    Price DECIMAL(10,2) NOT NULL,
    Stock INT
);

-- Create Orders table
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    ProductID INT,
    Quantity INT,
    OrderDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Insert into Customers
INSERT INTO Customers (CustomerID, Name, Email, Phone, Address) VALUES
(1, 'Aarav Singh', 'aarav@example.com', '9876543210', 'Mumbai'),
(2, 'Nisha Patel', 'nisha@example.com', NULL, 'Hyderabad'),
(3, 'Rohan Das', NULL, NULL, NULL);

-- Insert into Products
INSERT INTO Products (ProductID, Name, Price, Stock) VALUES
(101, 'Laptop', 50000.00, 10),
(102, 'Tablet', 15000.00, NULL),
(103, 'Phone', 20000.00, 30);

-- Insert into Orders
INSERT INTO Orders (OrderID, CustomerID, ProductID, Quantity, OrderDate) VALUES
(1001, 1, 101, 1, '2024-05-15'),
(1002, 2, 102, NULL, NULL),
(1003, 3, 103, 2, '2024-06-01');

-- Update NULLs
UPDATE Customers SET Phone = '9999999999' WHERE Phone IS NULL;
UPDATE Customers SET Email = 'default@example.com' WHERE Email IS NULL;
UPDATE Products SET Stock = 25 WHERE Stock IS NULL;
UPDATE Orders SET Quantity = 1 WHERE Quantity IS NULL;
UPDATE Orders SET OrderDate = '2024-06-25' WHERE OrderDate IS NULL;

-- Delete incomplete records (if any)
DELETE FROM Customers WHERE Email IS NULL AND Phone IS NULL;
DELETE FROM Orders WHERE Quantity IS NULL OR Quantity = 0;

-- Create archive table
CREATE TABLE ProductArchive AS
SELECT * FROM Products WHERE Stock > 10;

-- Delete a customer to test ON DELETE CASCADE
DELETE FROM Customers WHERE CustomerID = 1;

-- Final output
SELECT * FROM Orders;
